-- DD_USRDATA.DD_PARAM definition
CREATE TABLE DD_USRDATA.DD_PARAM (
	PARNAME CHAR(100) NOT NULL,
	PARVAL CHAR(1024) DEFAULT ' ' NOT NULL,
	CONSTRAINT PK_PARAM PRIMARY KEY (PARNAME)
);
CREATE UNIQUE INDEX DD_PARAM ON DD_USRDATA.DD_PARAM (PARNAME);

-- Scanning time (in seconds ex 300 = 5mn). Minimum value: 60s (default: 600s = 10 mn)
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('Supervision.IdleTime_Second' ,'600');
-- Number of data kept in the table DD_TUN_DST (in day ex: 1 = 1 day). Default: 5.
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL)  VALUES ('Supervision.Retention_Day' ,'5');
-- Environment selection PROD, TEST, TRNG, MODEL, DEPL, *ALL(all environments). Default: PROD.
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL)  VALUES ('Supervision.Selection' ,'PROD');

-- Snowflake DML Commands - Data Loading  : PUT
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('SnowFlakeTarget.Put', 'put file://&snowfile @~ auto_compress=false;');
-- Snowflake DML Commands - Data Loading  : COPY
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('SnowFlakeTarget.Copy', 'copy into "&dbname"."&schemaname".&snowtable from @~/&snowfile file_format = (type=csv FIELD_OPTIONALLY_ENCLOSED_BY = ''"'' ESCAPE =''\\'');');
-- Snowflake DML Commands - File Staging : REMOVE
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('SnowFlakeTarget.Remove', 'rm @~ pattern=''&snowfile'';');

