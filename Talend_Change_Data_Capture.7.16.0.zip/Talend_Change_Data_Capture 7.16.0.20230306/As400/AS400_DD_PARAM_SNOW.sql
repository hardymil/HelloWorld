-- Snowflake DML Commands - Data Loading  : PUT
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('SnowFlakeTarget.Put', 'put file://&snowfile @~ auto_compress=false;');
-- Snowflake DML Commands - Data Loading  : COPY
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('SnowFlakeTarget.Copy', 'copy into "&dbname"."&schemaname".&snowtable from @~/&snowfile file_format = (type=csv FIELD_OPTIONALLY_ENCLOSED_BY = ''"'' ESCAPE =''\\'');');
-- Snowflake DML Commands - File Staging : REMOVE
INSERT INTO DD_USRDATA.DD_PARAM (PARNAME,PARVAL) VALUES ('SnowFlakeTarget.Remove', 'rm @~ pattern=''&snowfile'';');

