-- --------------------------------------
-- replace mdb_dd_test by database name 
-- --------------------------------------
-- Find all type 
-- --------------------------------------
select data_type, count(*) as columns, count(distinct concat(col.table_schema, '.', col.table_name)) as tables
from information_schema.columns col, information_schema.tables tab,
(
select count(distinct concat(c.table_schema, '.', c.table_name)) as tables, count(*) as columns from information_schema.columns c
      join information_schema.tables t
           on c.table_schema = t.table_schema
           and c.table_name = t.table_name
      where t.table_schema not in ('information_schema', 'mysql', 'performance_schema', 'sys') and t.table_type = 'BASE TABLE' and t.table_schema='mdb_dd_test'
) sum_all
where  col.table_schema = tab.table_schema  and col.table_name = tab.table_name
and tab.table_schema not in ('information_schema', 'mysql', 'performance_schema', 'sys') and tab.table_type = 'BASE TABLE'
and tab.table_schema = 'mdb_dd_test'
group by data_type, sum_all.columns, sum_all.tables
order by columns desc, sum_all.columns, sum_all.tables;
-- --------------------------------------
-- Find table with  'binary', 'mediumblob', 'blob', 'longblob', 'text', 'longtext', 'mediumtext'
-- --------------------------------------
select tab.table_name 
from information_schema.columns col, information_schema.tables tab
where  col.table_schema = tab.table_schema  and col.table_name = tab.table_name
and tab.table_schema not in ('information_schema', 'mysql', 'performance_schema', 'sys') and tab.table_type = 'BASE TABLE'
and tab.table_schema = 'mdb_dd_test'
and data_type in ('binary', 'mediumblob', 'blob', 'longblob', 'text', 'longtext', 'mediumtext')
group by tab.table_name 
-- --------------------------------------
-- Find table without 'binary', 'mediumblob', 'blob', 'longblob', 'text', 'longtext', 'mediumtext'
-- --------------------------------------
select tab.table_name 
from information_schema.tables tab 
where tab.table_schema not in ('information_schema', 'mysql', 'performance_schema', 'sys') and tab.table_type = 'BASE TABLE'
and tab.table_schema = 'mdb_dd_test'
and tab.table_name not in (
	select tab.table_name 
	from information_schema.columns col, information_schema.tables tab
	where  col.table_schema = tab.table_schema  and col.table_name = tab.table_name
	and tab.table_schema not in ('information_schema', 'mysql', 'performance_schema', 'sys') and tab.table_type = 'BASE TABLE'
	and tab.table_schema = 'mdb_dd_test'
	and data_type in ('binary', 'mediumblob', 'blob', 'longblob', 'text', 'longtext', 'mediumtext')
	group by tab.table_name
)

