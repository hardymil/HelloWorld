CREATE DATABASE DD_TRAINING
go

use DD_TRAINING
go

SET DATEFORMAT YMD
go

:r 02_DATEKEY.sql
GO
:r 03_GEOGRAPHY.sql
GO
:r 04_PROMOTION.sql
GO
:r 05_CATEGORY.sql
GO
:r 06_SUBCATEGORY.sql
GO
:r 07_CUSTOMER.sql
GO
:r 08_EMPLOYEE.sql
GO
:r 09_PRODUCT.sql
GO
:r 10_SALES_part1.sql
GO
:r 10_SALES_part2.sql
GO
:exit