CREATE TABLE [Promotion]
 (
    [PROMOKEY] DECIMAL(10, 0) NOT NULL, 
    [PROMOAKEY] DECIMAL(10, 0), 
    [PROMONAME] VARCHAR(255), 
    [DISCOUNT] DECIMAL(15, 0), 
    [PROMOTYPE] VARCHAR(50), 
    [PROMOCAT] VARCHAR(50), 
    [STARTDATE] DATE, 
    [ENDDATE] DATE, 
    [MINQTY] DECIMAL(10, 0), 
    [MAXQTY] DECIMAL(10, 0), 
    CONSTRAINT [PK_Promotion] PRIMARY KEY ([PROMOKEY])
 )
 GO

INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+1, +1, 'No Discount', +0, 'No Discount', 'No Discount', '2010/06/01', '2013/12/31', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+2, +2, 'Volume Discount 11 to 14', +0, 'Volume Discount', 'Reseller', '2010/07/01', '2013/06/30', +11, +14);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+3, +3, 'Volume Discount 15 to 24', +0, 'Volume Discount', 'Reseller', '2010/07/01', '2013/06/30', +15, +24);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+4, +4, 'Volume Discount 25 to 40', +0, 'Volume Discount', 'Reseller', '2010/07/01', '2013/06/30', +25, +40);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+5, +5, 'Volume Discount 41 to 60', +0, 'Volume Discount', 'Reseller', '2010/07/01', '2013/06/30', +41, +60);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+6, +6, 'Volume Discount over 60', +0, 'Volume Discount', 'Reseller', '2010/07/01', '2013/06/30', +61, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+7, +7, 'Mountain-100 Clearance Sale', +0, 'Discontinued Product', 'Reseller', '2011/05/15', '2011/06/30', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+8, +8, 'Sport Helmet Discount-2002', +0, 'Seasonal Discount', 'Reseller', '2011/07/01', '2011/07/31', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+9, +9, 'Road-650 Overstock', +0, 'Excess Inventory', 'Reseller', '2011/07/01', '2011/08/31', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+10, +10, 'Mountain Tire Sale', +1, 'Excess Inventory', 'Customer', '2012/06/15', '2012/08/30', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+11, +11, 'Sport Helmet Discount-2003', +0, 'Seasonal Discount', 'Reseller', '2012/07/01', '2012/07/31', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+12, +12, 'LL Road Frame Sale', +0, 'Excess Inventory', 'Reseller', '2012/07/01', '2012/08/15', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+13, +13, 'Touring-3000 Promotion', +0, 'New Product', 'Reseller', '2012/07/01', '2012/09/30', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+14, +14, 'Touring-1000 Promotion', +0, 'New Product', 'Reseller', '2012/07/01', '2012/09/30', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+15, +15, 'Half-Price Pedal Sale', +1, 'Seasonal Discount', 'Customer', '2012/08/15', '2012/09/15', +0, +0);
INSERT INTO [Promotion] ([PROMOKEY], [PROMOAKEY], [PROMONAME], [DISCOUNT], [PROMOTYPE], [PROMOCAT], [STARTDATE], [ENDDATE], [MINQTY], [MAXQTY]) VALUES (+16, +16, 'Mountain-500 Silver Clearance Sale', +0, 'Discontinued Product', 'Reseller', '2013/05/01', '2013/06/30', +0, +0);
